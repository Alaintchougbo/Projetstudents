from django import forms
from django.contrib.auth.forms import UserCreationForm, PasswordChangeForm, SetPasswordForm, PasswordResetForm
from django.contrib.auth.models import User
from TchatLocations.models import Profile
class userform(UserCreationForm):
    first_name = forms.CharField(label='Nom', widget=forms.TextInput(attrs={'autofocus':True,'class':'form-control' }))
    last_name = forms.CharField(label='Prénom ', widget=forms.TextInput(attrs={'class':'form-control' }))
    email = forms.EmailField(label='E-mail', widget=forms.EmailInput(attrs={'class':'form-control'}))
    password1 = forms.CharField(label='Mot de passe', widget=forms.PasswordInput(attrs={'class':'form-control'}))
    password2 = forms.CharField(label='Confirmer Mot de passe ', widget=forms.PasswordInput(attrs={'class':'form-control'}))

    class Meta:
        model = User
        fields = ['first_name','last_name', 'email', 'password1', 'password1',]

class ReseatPassWordChangForm(PasswordResetForm):
    email = forms.CharField(label="E-mail*", widget=forms.TextInput(attrs={'autofocus':True, 'class':'form-control'}))
class ReseatPasswordSetForm(SetPasswordForm):
    new_password1 = forms.CharField(label="Nouveau mot de passe", widget=forms.PasswordInput(attrs={'autofocus':True, 'class':'form-control'}))
    new_password2 = forms.CharField(label="Confirmer mot de passe", widget=forms.PasswordInput(attrs={'class':'form-control'}))

class ProfilForm(forms.ModelForm):
    telephone  = forms.CharField(label="Téléphone", widget=forms.TextInput(attrs={'autofocus':True, 'class':'form-control'}))
    statut_noti = forms.CharField(label="Notification", widget=forms.TextInput(attrs={ 'class':'form-control'}))
    anniversaire = forms.DateField(label="Anniversaire", widget=forms.DateInput(attrs={ 'class':'form-control'}))
    genre = forms.CharField(label='Genre', widget=forms.TextInput(attrs={ 'class':'form-control'}))
    localisation = forms.CharField(label='Quartier', widget=forms.TextInput(attrs={ 'class':'form-control'}))
    langue_prefe = forms.CharField(label="Votre langue préféré", widget=forms.TextInput(attrs={ 'class':'form-control'}))
    class Meta:
        model = Profile
        fields = ['telephone', 'statut_noti', 'anniversaire', 'genre','localisation', 'langue_prefe']