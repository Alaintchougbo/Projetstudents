from django.shortcuts import render, redirect
from django.contrib.auth import login, logout, authenticate
from django.core.validators import validate_email
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from django.contrib import messages
from .forms import *

def connexion(request):
    user=""
    erreur = False
    message = ""
    if request.method == 'POST':
        password = request.POST['password']
        email = request.POST['email']
        if email is not None:
            try:
                validate_email(email)
            except:
                erreur = True
            message = 'E-mail non valide '
            if erreur == False:
                user = User.objects.filter(email=email).first()

            if user:
                auth_user = authenticate(username=user.username, password = password)
                if auth_user:
                    login(request, auth_user)
                    return redirect('location')
                else: 
                    erreur = True
                    message = "Mot de passe ou nom d'utilisateur incorrecte !"
            else: 
                erreur = True
                message = "Cet utilisateur nexiste pas "
    context = {
                'message':message,
                'erreur':erreur
            }
    return render(request, "Mon_Html/connexion.html", context)
def inscription(request):
    form = userform()
    if request.method == "POST":
        form = userform(request.POST)
        if form.is_valid():
            form.save()
            form = userform()
            messages.success(request, "Compte créer avec succès !")
            return redirect('connexion')
        else:
            messages.warning(request, "Création de compte échouer. Vérifier vos données entrer et reprenez !")
    else:
        form = userform()
    context = {'form':form}
    return render(request, 'Mon_Html/inscription.html', context)
def deconnexion(requeste):
    logout(requeste)
    return redirect('connexion')
"""ef profile(requeste, user_id):
    form = ProfilForm()
    if requeste.method == "POST":
        form = ProfilForm(requeste.POST)
        if form.is_valid():
            add = User.objects.get(pk=user_id)
            add.telephone = form.cleaned_data['telephone']
            add.statut_noti = form.cleaned_data['statut_noti']
            add.anniversaire = form.cleaned_data['anniversaire']
            add.genre = form.cleaned_data['genre']
            add.localisation = form.cleaned_data['localisation']
            add.langue_prefe = form.cleaned_data['langue_prefe']
            add.save()
            form = ProfilForm()
        else:
            messages.warning(requeste, "Vérifier vos données et réessayer !")
    else:
        form = ProfilForm()
    return render(requeste, 'Mon_Html/profile.html')
"""
# Create your views here.
