from authentification.forms import ReseatPassWordChangForm, ReseatPasswordSetForm
from . import views
from django.urls import path
from django.contrib.auth import views as auth_view

urlpatterns = [
    path('connexion/', views.connexion, name = 'connexion'), 
    path('inscription/', views.inscription, name='inscription'), 
    path('deconnexion/', views.deconnexion, name='deconnexion'),


    path('reinitial-mot-de-pass/', auth_view.PasswordResetView.as_view(template_name="Mon_Html/reinitialisermotpasse.html", form_class=ReseatPassWordChangForm), name="password_reset"),
    path('confirmation-mot-passe/<uidb64>/<token>/', auth_view.PasswordResetConfirmView.as_view(template_name="Mon_Html/reinitialisermotpasse_confirmer.html", form_class=ReseatPasswordSetForm), name="password_reset_confirm"),
    path('reinitial-mot-de-pass/termine/', auth_view.PasswordResetDoneView.as_view(template_name="Mon_Html/reinitialisermotpasse_sprimer.html"), name="password_reset_done"),
    path('complet-mot-passe/', auth_view.PasswordResetCompleteView.as_view(template_name="Mon_Html/reinitialisermotpasse_complet.html"), name="password_reset_complete"),
]
