from . import views
from django.urls import path

urlpatterns = [
    path('homes/', views.create_view, name="home")
]
