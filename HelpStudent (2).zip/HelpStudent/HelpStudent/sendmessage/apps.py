from django.apps import AppConfig


class SendmessageConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'sendmessage'
