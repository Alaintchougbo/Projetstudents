from .models import Assistance
from django import forms 

class AssistanceForm(forms.ModelForm): 
    fullname = forms.CharField(label="Nom complet", widget=forms.TextInput(attrs={'autofocus': True, 'class':'form-control'}),),
    email = forms.EmailField(label="Email", widget=forms.EmailInput(attrs={'classs': 'form-control'}))
    message = email = forms.CharField(label="Message", widget=forms.TextInput(attrs={'classs': 'form-control'}))

    class Meta :
        model = Assistance
        fields = ['fullname', 'email', 'message']


class SendFolder(forms.ModelForm):
    fullname = forms.CharField(label="Nom complet", widget=forms.TextInput(attrs={'autofocus': True, 'class':'form-control'}),),
    email = forms.EmailField(label="Email", widget=forms.TextInput(attrs={'autofocus': True, 'class':'form-control'}),),
    contenu = forms.FileField(label="Sélectionnez un fichier", widget=forms.FileInput(attrs={'class':'form-control'}),),

class PayementForm(forms.ModelForm):
    choix_payement