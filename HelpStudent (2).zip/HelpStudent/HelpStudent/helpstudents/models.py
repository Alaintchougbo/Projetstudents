from django.db import models
from django.contrib.auth.models import User
class Service(models.Model):
    name = models.CharField(max_length=100), 
    description = models.TextField()
    def __str__(self) -> str:
        return self.name

class Paiement(models.Model):
    Choix_Payement = [
        ('Momo', 'MTN momo'), 
        ('Money', 'Mobile money'),
        ('Virement', 'Compte Bancaire')
    ]
    type = models.CharField(max_length=100, choices=Choix_Payement), 
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    number_account = models.DecimalField(max_digits=24, decimal_places=0)
    date_demande = models.DateField()
    date_response = models.DateField()

class Sendholder(models.Model):
    fullname = models.CharField()
    emeil = models.EmailField()
    contenu = models.FileField()


    def __str__(self) -> str:
        return self.type
class Demande(models.Model):
    service = models.ForeignKey(Service, on_delete=models.CASCADE)
    date_demande = models.DateField()
    date_response = models.DateField()

class Assistance(models.Model):
    fullname = models.CharField(max_length=100)
    email = models.EmailField()
    message = models.TextField()
    date_demande = models.DateField()
    date_reponse = models.DateField()

    def __str__(self) -> str:
        return self.email, self.message
    

class Historique(models.Model):
    paiement = models.ForeignKey(Paiement, on_delete=models.CASCADE)
    demande= models.ForeignKey(Demande,  on_delete=models.CASCADE)
    assist = models.ForeignKey(Assistance, on_delete=models.CASCADE)

    

class Programme(models.Model):
    date = models.DateField()
    select_jours = [
        ('Lundi', 'Lundi'), 
        ('Mardi', 'Mardi'),
        ('Mercredi', 'Mercredi'),
        ('Jeudi', 'Jeudi'),
        ('Vendredi', 'Vendredi'),
        ('Samedi', 'Samedi')
    ]
    jours = models.CharField(max_length=100, choices=select_jours)
    heure_total = models.TimeField()
    heure_debut = models.TimeField()
    heure_fin = models.TimeField()
    heure_restante = models.TimeField()
    salle = models.CharField(max_length=10)


    def __str__(self) -> str:
            return self.date, self.jours, self.heure_debut, self.heure_total, self.heure_restante, self.heure_fin

    
    


class Professeur(models.Model):
    name = models.CharField(max_length=100)
    prenom = models.CharField(max_length=100)
    tel = models.IntegerField(max_length=10)
    email = models.EmailField()

    def __str__(self) -> str:
            return self.name, self.prenom, self.tel, self.email
    


class Cours(models.Model):
     id_cours = models.CharField(max_length=10,  primary_key=True)
     name = models.CharField(max_length=100)
     description = models.TextField()
     titulaire = models.ForeignKey(Professeur, on_delete=models.CASCADE )


     def __str__(self) -> str:
         return self.id_cours, self.name, self.description, self.titulaire

# Create your models here.
