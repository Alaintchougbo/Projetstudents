from django.apps import AppConfig


class HelpstudentsConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'helpstudents'
