from django.shortcuts import render, redirect
from .forms import AssistanceForm, HistoriqueForm 
from .models import Historique
from django.contrib.auth.models import User
from django.contrib.auth.decorators import login_required

def Assistance(request):
    form = AssistanceForm()
    if request.method == "POST":
         form = AssistanceForm(request.POST)
         if form.is_valid():
             form.save()
             form = AssistanceForm()
         else:
             message = "Entrer des données valides"
    else:
        form = AssistanceForm()

    context = {
        "message": message,
        "form": form
    }

    return render(request, 'assistance.html', context)

@login_required(login_url="connexion")
def Historique(request): 
    email = 
    mail = User.objects.filter(email = email)
    return render(request, 'historique.html')


# Create your views here.
